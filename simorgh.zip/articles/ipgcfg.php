<?php
	error_reporting(0);
	
    $Username = 'amozs5262207';
    $Password = 'PKQ9869m';    
    $merchantConfigID = '257430';
?>	